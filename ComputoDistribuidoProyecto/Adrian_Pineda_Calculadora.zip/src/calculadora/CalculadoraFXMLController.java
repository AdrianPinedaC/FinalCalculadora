/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package calculadora;

//import com.sun.javafx.logging.PlatformLogger;
//import com.sun.javafx.logging.PlatformLogger.Level;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.net.URL;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;

/**
 * FXML Controller class
 *
 * @author pined
 */
public class CalculadoraFXMLController implements Initializable {

    public String n="vacio";
    public String reg;
    public Boolean Limpio = true;
    public Boolean Decimal = false;
    public Boolean S = false;
    public Boolean R = false;
    public Boolean M = false;
    public Boolean D = false;
    public Boolean igual = false;
    
    @FXML
    private Label lbl_Display;
    @FXML
    private Button btn_clr;
    @FXML
    private Button btn_igual;
    @FXML
    private Button btn_8;
    @FXML
    private Button btn_4;
    @FXML
    private Button btn_9;
    @FXML
    private Button btn_5;
    @FXML
    private Button btn_6;
    @FXML
    public Button btn_1;
    @FXML
    private Button btn_2;
    @FXML
    private Button btn_suma;
    @FXML
    private Button btn_0;
    @FXML
    private Button btn_3;
    @FXML
    private Button btn_7;
    @FXML
    private Button btn_punto;
    @FXML
    private Button btn_resta;
    @FXML
    private Button btn_div;
    @FXML
    private Button btn_mult;
    @FXML
    private Label lbl_sumas;
    @FXML
    private Label lbl_divisiones;
    @FXML
    private Label lbl_multiplicaciones;
    @FXML
    private Label lbl_restas;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void Click(ActionEvent event) {
//        lbl_Display.setText("Funciona");
        System.out.println("Boton PUNTO Click");
        if (Decimal==false) {          
            n=".";
            numeros();
            Decimal = true;
        }else{
            System.out.println(" No puede haber mas de un punto decimal ");
        }
                        
    }
 

    @FXML
    private void limpia(ActionEvent event) {
        System.out.println("Clear");
        lbl_Display.setText("0");
        Limpio = true;
        Decimal = false;
        igual = false;
        simbolos('x');
    }

    //Refresca Dysplay
    public void numeros(){
        System.out.println("Entro func Numeros");
        if ( Limpio == true ) {
            lbl_Display.setText(n);
            reg = n;
            Limpio = false;
        }else{
            reg = reg + n;
            lbl_Display.setText(reg);
        }                
    }

    @FXML
    private void Click1(ActionEvent event) {
        //lbl_Display.setText("Funciona");
        System.out.println("Boton 1 Click");
        n="1";        
        numeros();
    }

    @FXML
    private void Click8(ActionEvent event) {
        System.out.println("Boton 8 Click");
        n="8";        
        numeros();
    }

    @FXML
    private void Click4(ActionEvent event) {
        System.out.println("Boton 4 Click");
        n="4";        
        numeros();
    }

    @FXML
    private void Click9(ActionEvent event) {
        System.out.println("Boton 9 Click");
        n="9";        
        numeros();
    }

    @FXML
    private void Click5(ActionEvent event) {
        System.out.println("Boton 5 Click");
        n="5";        
        numeros();
    }

    @FXML
    private void Click6(ActionEvent event) {
        System.out.println("Boton 6 Click");
        n="6";        
        numeros();
    }

    @FXML
    private void Click2(ActionEvent event) {
        System.out.println("Boton 2 Click");
        n="2";        
        numeros();
    }

    @FXML
    private void Click0(ActionEvent event) {
        System.out.println("Boton 0 Click");
        n="0";        
        numeros();
    }

    @FXML
    private void Click3(ActionEvent event) {
        System.out.println("Boton 3 Click");
        n="3";        
        numeros();
    }

    @FXML
    private void Click7(ActionEvent event) {
        System.out.println("Boton 7 Click");
        n="7";        
        numeros();
    }

    @FXML
    private void suma(ActionEvent event) {
         System.out.println("Boton SUMA Click");
         n="+";
         simbolos('S');
         numeros();
    }

    @FXML
    private void resta(ActionEvent event) {
         System.out.println("Boton RESTA Click");
         n="-";        
         simbolos('R');
         numeros();
    }

    @FXML
    private void divide(ActionEvent event) {
         System.out.println("Boton DIVIDE Click");
         n="/";    
         simbolos('D');
         numeros();
    }

    @FXML
    private void multiplica(ActionEvent event) {
         System.out.println("Boton MULTIPLICA Click");
         n="x";        
         simbolos('M');
         numeros();
    }
       
    @FXML
    private void opera(ActionEvent event) {
        
        final String HOST = "127.0.0.1";
        final int PUERTO = 50000;
        DataInputStream in;
        DataOutputStream out;
        String resultado = "";
        String op = lbl_Display.getText();
        Almacenar();
        
        try{
            Socket sc = new Socket(HOST, PUERTO);
            
            in = new DataInputStream(sc.getInputStream());     
            out = new DataOutputStream(sc.getOutputStream());  
            
            out.writeUTF(op);
            
            resultado = in.readUTF();
            
            System.out.print("Mensaje recibido: ");
            System.out.println(resultado);
            
            lbl_Display.setText(resultado);

            sc.close();
   
        } catch (IOException ex) {
            
            Logger.getLogger(CalculadoraFXMLController.class.getName()).log(Level.SEVERE, null, ex);
      
        }
         
        Almacenar();
        
        simbolos('x');
        
    }
    
    public void simbolos(char OP){
        switch (OP){
            case 'S':
                S = true;
                R = false;
                M = false;
                D = false;
                break;
            case 'R':
                S = false;
                R = true;
                M = false;
                D = false;
                break;
            case 'M':
                S = false;
                R = false;
                M = true;
                D = false;
                break;
            case 'D':
                S = false;
                R = false;
                M = false;
                D = true;
                break;
            default:
                S = false;
                R = false;
                M = false;
                D = false;
        }                
    }
            
    public void Almacenar(){
        String antes = " ";
        
        if (S == true) {
            antes += lbl_sumas.getText();
                        
            if (igual == true) {
                antes += "=";                
            }
            
            antes += lbl_Display.getText();
            lbl_sumas.setText(antes);
            antes += " ";
            lbl_sumas.setText(antes);
        }else if (R == true) {
            antes += lbl_restas.getText();
                        
            if (igual == true) {
                antes += "=";                
            }
            
            antes += lbl_Display.getText();
            lbl_restas.setText(antes);
            antes += " ";
            lbl_restas.setText(antes);
        }else if (M == true) {
            antes += lbl_multiplicaciones.getText();
                        
            if (igual == true) {
                antes += "=";                
            }
            
            antes += lbl_Display.getText();
            lbl_multiplicaciones.setText(antes);
            antes += " ";
            lbl_multiplicaciones.setText(antes);
        }else if (D == true) {
            antes += lbl_divisiones.getText();
                        
            if (igual == true) {
                antes += "=";                
            }
            
            antes += lbl_Display.getText();
            lbl_divisiones.setText(antes);
            antes += " ";
            lbl_divisiones.setText(antes);
        }
        
        if (igual == false) { igual = true; }
        
    }
        
        
}
    

