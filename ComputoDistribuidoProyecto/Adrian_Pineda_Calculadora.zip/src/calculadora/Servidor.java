
package calculadora;

import java.io.DataInputStream;     //Cliente  --> Servidor
import java.io.DataOutputStream;    //Servidor --> Cliente
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Servidor {
  
    
    public static void main(String[] args) {

        ServerSocket servidor = null;   //Socket del servidor
        Socket sc = null;               //Socket del Cliente
        final int PUERTO = 50000;
        DataInputStream in;
        DataOutputStream out;
        String respuesta = "0";

        
        try{
            servidor = new ServerSocket(PUERTO);
            System.out.println("Servidor iniciado");
            
            while (true){
                
                sc = servidor.accept();//accept se queda esperando, no avanzara al codigo de abajo hasta recibir algo
                System.out.println("-Cliente Conectado-");                
                
                in = new DataInputStream(sc.getInputStream());      //Recibe Mensaje del Cliente
                out = new DataOutputStream(sc.getOutputStream());   //Envia mensaje al Cliente
                
                String mensaje = in.readUTF();
                
                System.out.print("Mensaje recibido del cliente: ");
                System.out.println(mensaje);
                
                System.out.println("Procesando Operacion");
                respuesta = Operaciones(mensaje); 
                System.out.println("Operacion Procesada");
                System.out.println("Resultado");
                System.out.println(respuesta);
                System.out.println("Envia respuesta a Cliente");
                          
                out.writeUTF(respuesta);
                
                sc.close();         //Cierra cliente
                
                System.out.println("-Cliente Desconectado-");  
                respuesta = "0";
            }
             
        }catch(IOException ex) {
          Logger.getLogger(Servidor.class.getName()).log(Level.SEVERE, null, ex);
        }
 
        // TODO code application logic here
    }
    
    
    public static String Operaciones(String n ){
        int s = 0;
        int r = 0;
        int m = 0;
        int d = 0;
        String Resultado = "";
        
        
        s = n.indexOf('+');
        r = n.indexOf('-');
        m = n.indexOf('x');
        d = n.indexOf('/');
        
        if (s!= -1){
           Resultado = Suma(n,s);
        }else if (r!= -1){
           Resultado = Resta(n,r);
        }else if (m!= -1){
           Resultado = Multiplica(n,m);
        }else if (d!= -1){
           Resultado = Divide(n,d);
        }
        
        return Resultado;
    }
    
    public static int ParseNumberA(String n, int sig){
        String a = ""; 
        int A = 0;
        
        a = n.substring(0,sig);
        A = Integer.parseInt(a);
        
        return A; 
    }
    public static int ParseNumberB(String n, int sig){
        
        String b = "";        
        int B = 0;
                        
        b = n.substring(sig+1);        
        B = Integer.parseInt(b);
        
        return B;
    }
    /* Algoritmo de parseo (completo/original)
    
        String a = "";
        String b = "";
        int A = 0;
        int B = 0;
        
        a = n.substring(0,sig);
        b = n.substring(sig+1);
        
        A = Integer.parseInt(a);
        B = Integer.parseInt(b);
   
    */
    
    public static String Suma(String n, int sig){
        int respuesta = 0;
        int A = 0;
        int B = 0;
        String response= "";
        
        A = ParseNumberA(n, sig);
        B = ParseNumberB(n, sig);        
        
        respuesta = A + B;
        response = RespFin(respuesta);      
        return response;
    }
    public static String Resta(String n, int sig){
        int respuesta = 0;
        int A = 0;
        int B = 0;
        String response= "";
        
        A = ParseNumberA(n, sig);
        B = ParseNumberB(n, sig);        
        
        respuesta = A - B;
        response = RespFin(respuesta);      
        return response;
    }
    public static String Multiplica(String n, int sig){
        int respuesta = 0;
        //int A = 0;
        //int B = 0;
        String response= "";
        
        int A = ParseNumberA(n, sig);
        int B = ParseNumberB(n, sig);        
        
        respuesta = A * B;
        response = RespFin(respuesta);      
        return response;
    }
     public static String Divide(String n, int sig){
        double respuesta = 0;
        int A = 0;
        int B = 0;
        String response= "";
        
        A = ParseNumberA(n, sig);
        B = ParseNumberB(n, sig);        
         if (B == 0) {
             System.out.println("Error en division /0");
             response = "Error";
         }else{
            respuesta = A / B;
            response = String.valueOf(respuesta);
         }
        return response;
    }

    public static String RespFin(int respuesta){
        String FINAL = "";
        
        FINAL = String.valueOf(respuesta);
        
        return FINAL;
    }
     
}
